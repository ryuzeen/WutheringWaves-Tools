# wuwa-mod
Wuthering Waves pak mods

[![Discord](https://discordapp.com/api/guilds/1026295403282436097/widget.png?style=shield)](https://discord.com/invite/nfnUhqW8EY)
[![QQ群](https://i.postimg.cc/MGqtP1P8/image.png)](https://qm.qq.com/q/FVX6QpU5qi)


# How to use
1.Place the mod file in the  \Wuthering Waves\Wuthering Waves Game\Client\Content\Paks\\~mod\

2.find Wuthering Waves\Wuthering Waves Game\Client\Binaries\Win64\Client-Win64-Shipping.exe

3.run game with command line(startupArguments) "-fileopenlog"

# Functions

1.No skill cooldown

2.Automatically pick up treasure 

~~3.Skip the plot (have issues)~~

4.Ignoring falling damage

5.free monthcard ，store（Visual Only）

6.fake uidview

7.Disable anti cheat 

8.Disable Dither Effect

9.Disable log reporter 

10.Hit multiplier x15

11.God mode

12.Perception Range(Plants seem ineffective)(WIP)

13.Always Sunny (Night will still come. Just the weather)

14.kill Aura（wip，Now the radius is the whole world）

15.AutoAbsorb

# How to modify pak

1.Unpacking pak11 using [Fmodel](https://github.com/4sval/FModel)

AESkey = 0xE0D4C0AA387A268B29C397E3C0CAD934522EFC96BE5526D6288EA26351CDACC9

2.Find and modify files

3.Packaging using ue4.26



